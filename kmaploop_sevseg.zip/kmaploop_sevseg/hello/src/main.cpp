#include <Arduino.h>
void disp_7447(int D, int C, int B, int A)
{
  digitalWrite(2, A); //LSB
  digitalWrite(3, B);
  digitalWrite(4, C);
  digitalWrite(5, D); //MSB

}
void setup() {
    pinMode(2, OUTPUT);
    pinMode(3, OUTPUT);
    pinMode(4, OUTPUT);
    pinMode(5, OUTPUT);
}
int main(void)
{
    //printf("Z Y X W    D C B A\n");
    unsigned char  Z=0x00,Y=0x00,X=0x00,W=0x00;
    unsigned char one = 0x01;
    unsigned char A,B,C,D,a,b,c,d ;
    a = W;
    b = X;
    c = Y;
    d = Z;
    do {
        D = (W&X&Y&(~Z))|((~W)&(~X)&(~Y)&Z);
        B = ((~Z)&(~Y)&(~X)&W)|((~Z)&(~Y)&X&(~W))|((~Z)&Y&(~X)&W)|((~Z)&Y&X&(~W));
        C = ((~Z)&(~Y)&X&W)|((~Z)&Y&(~X)&(~W))|((~Z)&Y&(~X)&W)|((~Z)&Y&X&(~W));
        A = ((~W)&(~X)&(~Y)&(~Z))|((~W)&(X)&(~Y)&(~Z))|((~W)&(~X)&Y&(~Z))|((~W)&X&Y&(~Z))|((~W)&(~X)&(~Y)&(Z));
        disp_7447(D,C,B,A);
        delay(1500);
        //printf("%x %x %x %x    %x %x %x %x\n",one&Z,one&Y,one&X,one&W,one&D,one&C,one&B,one&A);
        W = A;
        X = B;
        Y = C;
        Z = D;
       } while (!((a==A)&&(b==B)&&(c==C)&&(d==D)));
    return 0;
}
